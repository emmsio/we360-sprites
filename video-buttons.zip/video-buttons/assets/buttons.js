$(function () {

    $(".video-active").hide().addClass("video-hidden");
    $(".sharing-active").hide().addClass("sharing-hidden");
    $(".phone-active").hide().addClass("phone-hidden");
    $(".microphone-active").hide().addClass("microphone-hidden");

    $(".video-toggle").click(function(){

        if ($(".video-active").hasClass("video-hidden")){
            $(".video-inactive").hide();
            $(".video-active").removeClass("video-hidden");
            $(".video-active").show();
        }
        else {
            $(".video-active").hide();
            $(".video-active").addClass("video-hidden");
            $(".video-inactive").show();
        }

    });
    $(".sharing-toggle").click(function(){

        if ($(".sharing-active").hasClass("sharing-hidden")){
            $(".sharing-inactive").hide();
            $(".sharing-active").removeClass("sharing-hidden");
            $(".sharing-active").show();
        }
        else {
            $(".sharing-active").hide();
            $(".sharing-active").addClass("sharing-hidden");
            $(".sharing-inactive").show();
        }

    });
    $(".phone-toggle").click(function(){

        if ($(".phone-active").hasClass("phone-hidden")){
            $(".phone-inactive").hide();
            $(".phone-active").removeClass("phone-hidden");
            $(".phone-active").show();
        }
        else {
            $(".phone-active").hide();
            $(".phone-active").addClass("phone-hidden");
            $(".phone-inactive").show();
        }

    });
    $(".microphone-toggle").click(function(){

        if ($(".microphone-active").hasClass("microphone-hidden")){
            $(".microphone-inactive").hide();
            $(".microphone-active").removeClass("microphone-hidden");
            $(".microphone-active").show();
        }
        else {
            $(".microphone-active").hide();
            $(".microphone-active").addClass("microphone-hidden");
            $(".microphone-inactive").show();
        }

    });

});